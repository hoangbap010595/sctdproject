﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sctd.somee.com.Models
{
    public class AccountViewModel
    {
        public Account Account { get; set; }
    }
}